/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
              
    $(".infiniteScrollBtn").click(function(){
        alert("clicked")           ;
        $.ajax({
            type : "POST",
            url : '../src/homeV5.php',
            success: function(data) {

                alert( data ); // shows whole dom
            },
            error : function() {
                alert("Sorry, The requested property could not be found.");
            }
        });
    });
    
    
    //console.log(data.name); // John
   //console.log(data.time); //  2pm
    
    $(".image").click(function(){
       
        $(this).append('<div style="position:absolute;top:0;background-color:pink;width:200px;height:200px;opacity:0.5;"><div style="top:80px;left:75px;position:absolute;width:30px">HELLO</div></div>');
    });
    
    
//    $(".infiniteScrollBtn").click(function(){
//    
//        $.ajax({
//            url: "../src/AjaxImages.php",
//            
//            success: function(data) {
//                $('.images').append(data);
//                
//            }
//        });
//    });
    
    
});

