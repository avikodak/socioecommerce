<?php
    global $GLOBAL_PHP_INCLUDES;$GLOBAL_PHP_INCLUDES="../php";
?>
