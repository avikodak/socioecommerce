<?php 
include '../php/FBBaseClass_Class.php';

$sample = new FBBaseClass();

?>