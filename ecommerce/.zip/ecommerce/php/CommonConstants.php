<?php

define($commonincludes, "includes");
define($scriptsIncludes,"scripts");
define($cssIncludes,"css");
define($imagesIncludes,"images");
?>
