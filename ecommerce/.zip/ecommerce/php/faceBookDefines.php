<?php
global $appId;
global $appSecret;
global $redirectUrl;


$appId="384618301573901";
$appSecret="f5cacafb3e96ee43cd2b07de413880f5";
$redirectUrl="http://localhost:8888/ecommerce/src/homeV3.php";
//define($appId, "384618301573901");
//define($app_secret,"f5cacafb3e96ee43cd2b07de413880f5");
//define($redirect_url,"http://localhost:8888/ecommerce/src/homeV3.php");
?>
