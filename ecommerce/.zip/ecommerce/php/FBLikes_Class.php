<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FBLikes_Class
 *
 * @author kodakand
 */
class FBLikes_Class {
    

    //put your code here
    private $dataArray;
    private $name;
    private $category;
    private $interestId;
    private $createdTime;
    private $nextUrl;
    private $previousUrl;
    // $interest can be an array
    
    /**
     * @param type $categories
     * @return type interests array
     */
    function likesBasedOnCategory($categories)
    {
      return $likesBasedOnCategory;  
    }

}

?>
