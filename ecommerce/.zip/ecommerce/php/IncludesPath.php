<?php

/*FB INCLUDES*/
global $FB_PHPSDK; $FB_PHPSDK ="../php/php-sdk";
global $FB_PHP; $FB_PHP="../php/php-sdk/src/facebook.php";
global $FB_GLOBAL_DEFINES;$FB_GLOBAL_DEFINES="../php/faceBookDefines.php";
global $FB_COMMON_FUNCTION;$FB_COMMON_FUNCTION="./php/FbFunctions.php";
global $FBINTERESTS_Class;$FBINTERESTS_Class="../php/FBInterests_Class.php";
global $FB_BASE_CLASS;$FB_BASE_CLASS="../php/FBBaseClass_Class.php";
/* Site Urls and Includes*/
global $HOME_PAGE_URL;$HOME_PAGE_URL="http://localhost:8888/ecommerce/src/homeV3.php";
global $LOGIN_PAGE_NO_USER_URL;$LOGIN_PAGE_NO_USER_URL="http://localhost:8888/ecommerce/src/loginV4Test.php";
global $LOGIN_PAGE_NO_SESSION_URL;$LOGIN_PAGE_NO_SESSION_URL="http://localhost:8888/ecommerce/src/loginV4Test.php";

?>
